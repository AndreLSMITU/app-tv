Projeto IPTV SMATVPro Clone - Estrutura básica.
Copie os arquivos do ChatGPT para as pastas correspondentes.